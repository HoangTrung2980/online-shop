package linhnhn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import linhnhn.dto.BookDTO;
import linhnhn.database.DBUtils;

/**
 *
 * @author NgocLinh
 */
public class BookDAO {

    // get all Books
    public static ArrayList<BookDTO> getBooks() {
        ArrayList<BookDTO> list = new ArrayList<>();
        Connection con = null;

        try {
            con = DBUtils.makeConnection();
            if (con != null) {
                String sql = "Select bookId, title, imgPath, description, price, quantity From Book";
                PreparedStatement psm = con.prepareStatement(sql);
                ResultSet rs = psm.executeQuery();

                if (rs != null) {
                    while (rs.next()) {
                        int bookId = rs.getInt("bookId");
                        String title = rs.getString("title");
                        String imgPath = rs.getString("imgPath");
                        String description = rs.getString("description");
                        String price = rs.getString("price");
                        int quantity = rs.getInt("quantity");
                        BookDTO book = new BookDTO(bookId, title, imgPath, description, price, quantity);
                        list.add(book);
                    }
                }
            }
        } catch (SQLException e) {
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                }
            }
        }
        return list;
    }

    // get Book by ID
    public BookDTO getBookByID(String bookId) throws SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        String sql = "Select * From Book where bookId = ?";
        try {
            con = DBUtils.makeConnection();
            if (con != null) {
                stm = con.prepareStatement(sql);
                stm.setString(1, bookId);

                ResultSet rs = stm.executeQuery(); //nhan kq tra ve
                while (rs.next()) {
                    return new BookDTO(rs.getInt(1), rs.getString(2),
                            rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6));
                }
            }

        } catch (SQLException e) {
        } finally {
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return null;
    }

    // Add new Book
    public void insertBook(String bookId, String title, String imgPath, String description, String price, String quantity) throws SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        String sql = "Insert into Book(bookId, title, imgPath, description, price, quantity)"
                + "values(?,?,?,?,?,?)";
        try {
            con = DBUtils.makeConnection();
            stm = con.prepareStatement(sql);
            stm.setString(1, bookId);
            stm.setString(2, title);
            stm.setString(3, imgPath);
            stm.setString(4, description);
            stm.setString(5, price);
            stm.setString(6, quantity);

            stm.executeUpdate();
        } catch (SQLException e) {
        } finally {
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    // Delete Book
    public boolean deleteBook(String bookId) throws SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        String sql = "Delete from Book\n"
                + "Where bookId = ?";
        try {
            con = DBUtils.makeConnection();
            if (con != null) {
                stm = con.prepareStatement(sql);
                stm.setString(1, bookId);
                int row = stm.executeUpdate(); // trả về int (số dòng nó execute dc)
                if (row > 0) {
                    return true;
                }
            }
        } finally {

            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return false;
    }
    
    
    
    // Update Book
    public void updateBook(String bookId, String title, String imgPath, String description, String price, String quantity) throws SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        String sql = "Update Book Set title = ?, imgPath = ?, description = ?, price = ?, quantity = ?  Where bookId = ?";

        try {
            con = DBUtils.makeConnection();
            stm = con.prepareStatement(sql);
            stm.setString(1, title);
            stm.setString(2, imgPath);
            stm.setString(3, description);
            stm.setString(4, price);
            stm.setString(5, quantity);
            stm.setString(6, bookId);

            stm.executeUpdate(); // trả về int (số dòng nó execute dc)

        } finally {
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }


}
