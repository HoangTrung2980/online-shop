package linhnhn.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import linhnhn.dao.RegistrationDAO;
import linhnhn.dao.RegistrationInsertError;

/**
 *
 * @author NgocLinh
 */
public class RegisterController extends HttpServlet {

    private final String LOGINPAGE = "login.html";
    private final String REGISTERPAGE = "register.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NamingException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            RegistrationDAO dao = new RegistrationDAO();
            RegistrationInsertError err = new RegistrationInsertError();
            boolean error = false;
            String url = REGISTERPAGE;
            try {
                String username = request.getParameter("txtUsername");
                String password = request.getParameter("txtPassword");
                String confirmPassword = request.getParameter("txtConfirmPassword");
                String fullname = request.getParameter("txtFullname");

                System.out.println(username);

                if (username.trim().length() < 6 || username.trim().length() > 15) {
                    error = true;
                    err.setUsernameLengthErr("Username is required to be 6 - 15 characters!");
                }
                if (password.trim().length() < 6 || password.trim().length() > 20) {
                    error = true;
                    err.setPasswordLengthErr("Password is required to be 6 - 20 characters!");
                }
                if (!password.trim().equals(confirmPassword.trim())) {
                    error = true;
                    err.setConfirmNotMatch("Confirm password is required to be matched the password!");
                }
                if (fullname.trim().length() < 2 || fullname.trim().length() > 50) {
                    error = true;
                    err.setFullNameLengthErr("Fullname is required to be 6 - 15 characters!");
                }

                if (error) {
                    request.setAttribute("INSERTERROR", err);                    
                } else {
                    boolean result = dao.registerAccount(username, password, fullname, false);
                    if (result) {
                        url = LOGINPAGE;
                    }
                }
            } catch (SQLException e) {
                request.setAttribute("INSERTERROR", err);
                error = true;
                err.setUsernameIsExisted("Username is existed");
            } finally {
                RequestDispatcher rd = request.getRequestDispatcher(url);
                rd.forward(request, response);
            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (NamingException ex) {
            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (NamingException ex) {
            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
